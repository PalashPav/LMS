// function formValidation(){
//     let password = document.MyForm.password.value;
//     let username = document.MyForm.username.value;

//     let demoPassword = "palash123";
     
//     if(password!=demoPassword){
//           alert("Password is not matched! Try again");
//     }

 
// }